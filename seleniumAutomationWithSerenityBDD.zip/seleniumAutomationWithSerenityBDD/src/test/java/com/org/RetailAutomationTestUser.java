package com.org;

import jdk.nashorn.internal.runtime.logging.Logger;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;

@Logger
@RunWith(SerenityRunner.class)
public class RetailAutomationTestUser {

    @Steps
    SeleniumAutomation retailUser;

    @Test
    public void RetailAutomationTest()

    {
        retailUser.newUserLogin();
        retailUser.addNewItemToCart();
        retailUser.existingUserLogin();
        retailUser.closeBrowser();
    }


}

