package com.org;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.junit.Test;

import static io.restassured.RestAssured.given;


public class APIAutomation {

    String apiUrl = "http://currencyconverter.kowabunga.net/converter.asmx?WSDL";

    String apiUSDToGBPBody = "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "  <soap:Body>\n" +
            "    <GetConversionRate xmlns=\"http://tempuri.org/\">\n" +
            "      <CurrencyFrom>USD</CurrencyFrom>\n" +
            "      <CurrencyTo>GBP</CurrencyTo>\n" +
            "      <RateDate>2018-09-23</RateDate>\n" +
            "    </GetConversionRate>\n" +
            "  </soap:Body>\n" +
            "</soap:Envelope>";
    String apiGBPToUSDBody = "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "  <soap:Body>\n" +
            "    <GetConversionRate xmlns=\"http://tempuri.org/\">\n" +
            "      <CurrencyFrom>GBP</CurrencyFrom>\n" +
            "      <CurrencyTo>USD</CurrencyTo>\n" +
            "      <RateDate>2018-09-23</RateDate>\n" +
            "    </GetConversionRate>\n" +
            "  </soap:Body>\n" +
            "</soap:Envelope>";

    String invalidApiBody = "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "  <soap:Body>\n" +
            "    <GetConversionRate xmlns=\"http://tempuri.org/\">\n" +
            "      <CurrencyFrom>USD</CurrencyFrom>\n" +
            "      <CurrencyTo>GBP</CurrencyTo>\n" +
            "      <RateDate>201-12-22</RateDate>\n" +
            "    </GetConversionRate>\n" +
            "  </soap:Body>\n" +
            "</soap:Envelope>";

    public static String getConversionRateResult;


    @Test
    public void usdToGBP() throws NullPointerException {
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.setBody(apiUSDToGBPBody);
        builder.setBaseUri(apiUrl);
        //Setting content type as application/json or application/xml
        builder.setContentType("text/xml;charset=UTF-8");
        RequestSpecification requestSpec = builder.build();
        Response response = given().auth().preemptive().basic("", "").spec(requestSpec).when().post(apiUrl);
        ResponseBody responseBody = response.getBody();
        int result = response.getStatusCode();
        Assert.assertEquals(result, 200);
        //System.out.println(responseBody.asString());
        String responseString = responseBody.asString();
        getConversionRateResult = new XmlPath(responseString).getString("Envelope.Body.GetConversionRateResponse.GetConversionRateResult");
        Assert.assertEquals("0.7602687303342120928650395442", getConversionRateResult);


    }

    @Test
    public void invalidUsdToGbp() {
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.setBody(invalidApiBody);
        builder.setBaseUri(apiUrl);
        builder.setContentType("text/xml;charset=UTF-8");
        RequestSpecification requestSpec = builder.build();
        Response response = given().auth().preemptive().basic("", "").spec(requestSpec).when().post(apiUrl);
        int result = response.getStatusCode();
        Assert.assertEquals(result, 500);

    }

    @Test
    public void gbpToUSD() {
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.setBody(apiGBPToUSDBody);
        builder.setBaseUri(apiUrl);
        builder.setContentType("text/xml;charset=UTF-8");
        RequestSpecification requestSpec = builder.build();
        Response response = given().auth().preemptive().basic("", "").spec(requestSpec).when().post(apiUrl);
        ResponseBody responseBody = response.getBody();
        int result = response.getStatusCode();
        Assert.assertEquals(result, 200);
        //   System.out.println(responseBody.asString());
        String responseString = responseBody.asString();
        String getConversionRateResultGbp = new XmlPath(responseString).getString("Envelope.Body.GetConversionRateResponse.GetConversionRateResult");
        Assert.assertEquals("1.3153243847874720357941834452", getConversionRateResultGbp);


    }


}

