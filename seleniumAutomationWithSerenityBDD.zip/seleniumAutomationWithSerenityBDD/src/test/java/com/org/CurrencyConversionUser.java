package com.org;


import jdk.nashorn.internal.runtime.logging.Logger;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;

@Logger
@RunWith(SerenityRunner.class)
public class CurrencyConversionUser {
    @Steps
    APIAutomation apiAutomationUser;

    @Test
    public void CurrencyConversionChecker() {
        apiAutomationUser.usdToGBP();
        apiAutomationUser.invalidUsdToGbp();
        apiAutomationUser.gbpToUSD();
    }
}
